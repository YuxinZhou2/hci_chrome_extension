//
// Button Group
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const ButtonGroupPlugin: BvPlugin

// Component: b-button-group
export declare class BButtonGroup extends BvComponent {}
