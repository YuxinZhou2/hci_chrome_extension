//
// Form Select
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const FormSelectPlugin: BvPlugin

// Component: b-form-select
export declare class BFormSelect extends BvComponent {}
