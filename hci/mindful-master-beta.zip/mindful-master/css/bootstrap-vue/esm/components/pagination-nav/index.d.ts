//
// PaginationNav
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const PaginationNavPlugin: BvPlugin

// Component: b-pagination-nav
export declare class BPaginationNav extends BvComponent {}
