//
// Popover
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const PopoverPlugin: BvPlugin

// Component: b-popover
export declare class BPopover extends BvComponent {}
