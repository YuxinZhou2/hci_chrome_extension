//
// Jumbotron
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const JumbotronPlugin: BvPlugin

// Component: b-jumbotron
export declare class BJumbotron extends BvComponent {}
