//
// Tooltip
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const TooltipPlugin: BvPlugin

// Component: b-tooltip
export declare class BTooltip extends BvComponent {}
