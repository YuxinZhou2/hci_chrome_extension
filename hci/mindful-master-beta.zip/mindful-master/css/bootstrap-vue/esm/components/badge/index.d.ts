//
// Badge
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const BadgePlugin: BvPlugin

// Component: b-badge
export declare class BBadge extends BvComponent {}
