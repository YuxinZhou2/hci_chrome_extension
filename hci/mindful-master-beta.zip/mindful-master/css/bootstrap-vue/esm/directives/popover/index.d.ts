//
// VBPopover
//
import Vue, { DirectiveOptions } from 'vue'
import { BvPlugin } from '../../'

// Plugin
export declare const VBPopoverPlugin: BvPlugin

// directive: v-b-popover
export declare const VBPopover: DirectiveOptions
