//
// VBModal
//
import Vue, { DirectiveOptions } from 'vue'
import { BvPlugin } from '../../'

// Plugin
export declare const VBModalPlugin: BvPlugin

// directive: v-b-modal
export declare const VBModal: DirectiveOptions
